
public class Time {
    private int hour;
    private int minute;
    private int second;

    public Time() {

    }

    public Time(int hour, int minute, int second) {
        this.hour = hour;
        this.minute = minute;
        this.second = second;
    }

    //setter

    public void setHour(int hour) {
        this.hour = hour;
    }

    public void setMinute(int minute) {
        this.minute = minute;
    }

    public void setSecond(int second) {
        this.second = second;
    }
    public void setTime(int hour, int minute, int second){
        this.hour = hour;
        this.minute = minute;
        this.second = second;
    }

    //getter
    public int getHour() {
        return hour;
    }

    public int getMinute() {
        return minute;
    }

    public int getSecond() {
        return second;
    }

    @Override
    public String toString() {
//        return "Time{" +
//                "hour=" + hour +
//                ", minute=" + minute +
//                ", second=" + second +
//                '}';
        return (String.format("%02d:%02d:%02d",getHour(), getMinute(), getSecond()));
    }
    public Time nextSecond(){
        Time nextTime = new Time();
        nextTime.second++;
        //System.out.println("time: "+ nextTime);
        if(nextTime.second ==60) {
            nextTime.second = 0;
            nextTime.minute += 1;
           // System.out.println("time: "+ nextTime);
        }
        if(nextTime.minute ==60){
            nextTime.minute = 0;
            nextTime.hour +=1;
            //System.out.println("time: "+ nextTime);
        }
        if(nextTime.hour == 24){
            nextTime.hour =0;
        }
        return nextTime;
    }
    public Time previousSecond(){
        Time previousTime = new Time();
        previousTime.second -=1;
        if(previousTime.second < 0) {
            previousTime.second = 59;
            previousTime.minute -= 1;
        }
        if(previousTime.minute < 0){
            previousTime.minute =59;
            previousTime.hour -=1;
        }
        if(previousTime.hour <0){
            previousTime.hour =23;
        }
        return previousTime;
    }
}
